//Author: Sophie Biondolillo
//Date: 04/20/2025
//Purpose: Item tracking application for Corner Grocer

#include "grocerList.h"
#include <iomanip>
#include <iostream>
#include <fstream>
#include <vector>
#include <string>


using namespace std;

int main() {



    string file = "CS210_Project_Three_Input_File.txt";

    //Creates new class object 
    groceryList object;

    //Reads all integers in the file to a vector
    const vector<int>& itemCount = object.readFileCount(file);

    //Reads all strings in the file to a vector
    const vector<string>& itemName = object.readFileName(file);

    //Backs up to output file "frequency.dat"
    void fileBackup(itemCount, itemName);

    //Prompts menu
    int menuChoice = object.displayMenu();


    //Loops until user confirms exit 
    while (menuChoice != 4) {
        if (menuChoice == 1) {
            object.optionOne(itemCount, itemName);
        }

        else if (menuChoice == 2) {
            object.optionTwo(itemCount, itemName);
        }

        else if (menuChoice == 3) {
            object.optionThree(itemCount, itemName);
        }

        else {
            cout << "Invalid choice. Try again." << endl;
        }
        menuChoice = object.displayMenu();

    }



    return 0;
}
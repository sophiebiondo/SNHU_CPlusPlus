//Author: Sophie Biondolillo
//Date: 04/20/2025
//Purpose: Item tracking application for Corner Grocer

#include "grocerList.h"
#include <vector>
#include <string>
#include <iostream>
#include <iomanip>
#include <fstream>

using namespace std;


//Constructor
groceryList::groceryList() {}



//Reads user-entered file and writes the integers found to a vector
vector<int> groceryList::readFileCount(const string& fileName) {

	vector<int> itemCount;

	ifstream inputFile(fileName);
	
	string line;
	if (!inputFile.eof()) {
		while (getline(inputFile, line)) {
			if (!line.empty()) {
				itemCount.push_back(stoi(line));
			}
		}
	
		inputFile.close();
		
	}
	else {
		cout << "Cannot open file." << endl;
	}
	return itemCount;

}

std::vector<std::string> groceryList::readFileName(const std::string& fileName) {

	vector<string> itemName;

	ifstream inputFile2 (fileName);

	string line;
	
	if (!inputFile2.eof()) {

		while (getline(inputFile2, line)) {
			if (!line.empty()) {
				itemName.push_back(line);
				
			}
		}
		
		inputFile2.close();
	}
	else {
		cout << "Cannot open file." << endl;
	}
	return itemName;
}

//Creates a backup file of vectors read into program
void fileBackup(const vector<int>& itemCount, const vector<string>& itemName) {

	ofstream outputFile("frequency.dat");

	for (string readStr : itemName) {
		for (int readInt : itemCount) {

			outputFile >> itemName + ": " >> itemCount >> endl;

		}
	}

	outputFile.close();
	return;
}


//Displays menu and returns a user option
int groceryList::displayMenu() {

	//Prints menu to screen
	cout << "********************************************" << endl;
	cout << "*                                          *" << endl;
	cout << "*             Corner Grocer                *" << endl;
	cout << "*                                          *" << endl;
	cout << "********************************************" << endl << endl << endl;

	cout << "Press 1 for item lookup." << endl;
	cout << "Press 2 for item purchase frequency." << endl;
	cout << "Press 3 for item purchase frequency visual." << endl;
	cout << "Press 4 to exit." << endl << endl;
	cout << "********************************************" << endl << endl << endl;


	cin >> menuChoice;

	//User input validation
	if (cin.fail() || menuChoice > 4 || menuChoice < 1) {
		cin.clear();
		cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
		cout << "Try again." << endl;
		cin >> menuChoice;
	}

	return menuChoice;


}

//Looks up a user-entered item in the directory and outputs item quantity if a match is found
void groceryList::optionOne(const vector<int>& itemCount, const vector<string>& itemName) {


	//Validates both vectors for function usage
	if (itemName.size() != itemCount.size()) {
		cout << "Error: Item names and counts do not match in size!" << endl;
		return;
	}
	else if ((itemName.size() == 0) || (itemCount.size() == 0)) {
		cout << "Error: No items found!" << endl;
		return;
	}



	cout << "Enter the item name: " << endl;
	cin >> itemLookup;
	cin.ignore(numeric_limits<streamsize>::max(), '\n');
	



	//Iterates through itemName to find a match to the user input
	//If all the items have been iterated through without a match, the user is returned to menu
	bool found = false;
	for (int k = 0; k < itemName.size(); k++) {
		if (itemLookup == itemName[k]) {
			cout << "Quantity: " << itemCount[k] << endl;
			found = true;
			break;
		}
	}

	//User input validation
	if (!found) {
		cout << "Item not found." << endl;
	}


	return;
}


//Prints an itemized inventory to screen
void groceryList::optionTwo(const vector<int>& itemCount, const vector<string>& itemName) {

	//Validates both vectors for function usage
	if (itemName.size() != itemCount.size()) {
		cout << "Error: Item names and counts do not match in size!" << endl;
		return;
	}
	else if ((itemName.size() == 0) || (itemCount.size() == 0)) {
		cout << "Error: No items found!" << endl;
		return;
	}
	

	cout << "********************************************" << endl;
	cout << "*                                          *" << endl;
	cout << "*           Itemized Inventory             *" << endl;
	cout << "*                                          *" << endl;
	cout << "********************************************" << endl;

	//Iterates through both vectors
	for (int i = 0; i < itemName.size(); i++) {
		cout << itemName[i] << ": " << itemCount[i] << endl;
	}

	cout << endl;
	cout << "*******************************************" << endl << endl;


	return;
}

//Prints an itemized inventory histogram to screen
void groceryList::optionThree(const vector<int>& itemCount, const vector<string>& itemName) {

	//Validates both vectors for function usage
	if (itemName.size() != itemCount.size()) {
		cout << "Error: Item names and counts do not match in size!" << endl;
		return;
	}
	else if ((itemName.size() == 0) || (itemCount.size() == 0)) {
		cout << "Error: No items found!" << endl;
		return;
	}
	

	cout << "********************************************" << endl;
	cout << "*                                          *" << endl;
	cout << "*       Itemized Inventory Histogram       *" << endl;
	cout << "*                                          *" << endl;
	cout << "********************************************" << endl;


	//Iterates through both vectors 
	for (int j = 0; j < itemName.size(); j++) {
		cout << itemName[j] << ": ";

		for (int y = 0; y <= itemCount[j]; y++) {
			cout << "*";
		}

		cout << endl;
	}

	cout << endl;
	cout << "*******************************************" << endl << endl;


	return;
}
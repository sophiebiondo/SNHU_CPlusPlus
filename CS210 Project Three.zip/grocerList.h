//Author: Sophie Biondolillo
//Date: 04/20/2025
//Purpose: Item tracking application for Corner Grocer


#ifndef GROCER_LIST_H
#define GROCER_LIST_H

#include <string>
#include <vector>


class groceryList {

private:
    std::vector<int> itemCount{};
    std::vector<std::string> itemName{};
    int menuChoice{};
    std::string itemLookup{};
    std::string fileName{};

public:
    groceryList();

    std::vector<int> readFileCount(const std::string& fileName);
    std::vector<std::string> readFileName(const std::string& fileName);
    void fileBackup(std::const vector<int>& itemCount, std::const vector<string>& itemName)
    int displayMenu();
    void optionOne(const std::vector<int>& itemCount, const std::vector<std::string>& itemName);
    void optionTwo(const std::vector<int>& itemCount, const std::vector<std::string>& itemName);
    void optionThree(const std::vector<int>& itemCount, const std::vector<std::string>& itemName);
};


#endif
